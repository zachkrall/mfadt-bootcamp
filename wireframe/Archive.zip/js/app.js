// console.log('hi');

var slides = document.getElementsByClassName('slide');
var indicators = document.getElementsByClassName('indicator');
// console.log(slides);

var counter = 0;

console.log( slides );

setInterval(updateSlides, 3000);

function updateSlides() {

  let max = slides.length-1;

  if( counter == 0 ){
    slides[max].classList.remove('active');
    slides[counter].classList.add('active');

    indicators[max].classList.remove('active');
    indicators[counter].classList.add('active');
  } else {
    slides[counter-1].classList.remove('active');
    slides[counter].classList.add('active');

    indicators[counter-1].classList.remove('active');
    indicators[counter].classList.add('active');
  }

  if ( counter < max ){
    counter++;
  } else {
    counter = 0;
  }
}
